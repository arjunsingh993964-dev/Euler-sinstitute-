Euler's Institute Formula Library
=================================
Open index.html in a browser or upload it to your website/GitHub Pages.

Features:
- Class 8, 9, 10, 11 and 12
- Subject filter and formula search
- Formula cards with detail pop-up: meaning, usage and example
- Responsive mobile layout; no server required for the formula page

Important:
This package is a formula-library starter/revision reference, not a guarantee of every formula in every edition of Bihar Board books. Check the latest official syllabus/textbooks.
The index.html is a standalone formula-library page. It does not preserve the Firebase login, books list, or PDF viewer from your pasted app. Merge the formula section into your original page if you need those features retained.
